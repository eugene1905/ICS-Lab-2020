/* 
========================================================================
	1900094810 Eugene Yu Jun Hao
  	csim.c - cache simulator
  	1.Read Arguments
  	2.Add TIME counter for every operation
  	3.Get tag,set index from address given
  	4.Check if the data is in cache using tag and set index
  	    a:Data Found(Hit!)-update hit count
  	    b:Not Found(Miss!)-update miss count
  	        i:Set full- Evict and replace with LRU policy, update evict count
  	        ii:Set not full- Fetch data to empty line
  	5.PrintSummary()
========================================================================
*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <getopt.h>
#include <unistd.h>
#include "cachelab.h"
#define SIZE 64

// Arguments
typedef struct {
    int verbose; //-v
    int s; // Each cache has S = 2^s sets
    int E; // Each set has E cache lines
    int b; // Each block has B = 2^b bytes
    int t; // tag has t bits
    char *filePath;
}input_args;
input_args Args;

typedef struct{
    unsigned long tag; // current data stored
    unsigned long lastVisit;  // last load/store
}cacheLine;

// input arguments
void setArgs(int argc, char** argv){
    Args.verbose = 0;
    int opt;
    while(-1 != (opt = getopt(argc, argv, "hv:s:E:b:t:"))){
	switch(opt){
	    case 'v':
		Args.verbose = 1;
	    case 's': 
	        Args.s = atoi(optarg);
        	break;
            case 'E':
        	Args.E = atoi(optarg);
        	break;
            case 'b':
        	Args.b = atoi(optarg);
        	break;
            case 't':
        	Args.filePath = optarg;
        }
    }
    Args.t = SIZE - Args.b - Args.s;
    return;
}

// Visit cache and update hit/miss/evict count
void solve(unsigned long address, cacheLine* cache, int cnt[3]) {
    static int TIME = 0;
    TIME++;
    //Address of word: [t bits of tag] + [s bits of set index] + [b bits of block offset]
    unsigned long tag = address >> (SIZE - Args.t);
    int set_index = (int) ((address << Args.t) >> (Args.t + Args.b));
    int pos = set_index * Args.E;
    int nextLine = pos + Args.E;
    int idx = pos;
    for(; idx < nextLine; idx++){
        if(cache[idx].tag == tag && cache[idx].lastVisit != 0){ // Hit
            cnt[0]++;
            cache[idx].lastVisit = TIME;
            return;
        } 
        else if(cache[idx].lastVisit == 0){ // Miss: Set is not full yet
            cnt[1]++;
            cache[idx].lastVisit = TIME;
            cache[idx].tag = tag;
            return;
        }
        else if(cache[idx].lastVisit < cache[pos].lastVisit)
            pos = idx;
    }
    // Set is full, evict with LRU policy
    cnt[1]++;
    cnt[2]++;
    cache[pos].lastVisit = TIME;
    cache[pos].tag = tag;
    return;
}

int main(int argc, char **argv){
    setArgs(argc,argv);
    if(Args.filePath == NULL)
        return 0;
    FILE *fp = fopen(Args.filePath,"r");
    int res[3]; // 0:hit, 1:miss, 2:evict
    for(int i=0; i<3; i++){
        res[i] = 0;
    }
    int Capacity = (1 << Args.s) * Args.E * sizeof(cacheLine);// S * E
    cacheLine* cache = malloc(Capacity); 

    char opt;
    unsigned long address;
    int block;
    while(fscanf(fp," %c %lx,%d", &opt, &address, &block) > 0){
	if(Args.verbose){
            printf("%c %lx,%d\n",opt,address,block);
        }
	switch(opt){
	   case'I':
		break;
	   case'M':
		solve(address,cache,res);
           default:
		solve(address,cache,res);
        }
    }
    fclose(fp);
    free(cache);
    printSummary(res[0], res[1], res[2]);
    return 0;
}
