/*<Eugene Yu Jun Hao 1900094810 proxy.c>
 * cache not implemented
 */

#include"csapp.h"
#include "sbuf.h"

/* Recommended max cache and object sizes */
#define MAX_CACHE_SIZE 1049000
#define MAX_OBJECT_SIZE 102400
#define SBUFSIZE 16
#define NTHREADS 4

/* You won't lose style points for including this long line in your code */
static const char *user_agent_hdr = "User-Agent: Mozilla/5.0 (X11; Linux x86_64; rv:10.0.3) Gecko/20120305 Firefox/10.0.3\r\n";

void doit(int connfd);
void parse_uri(char *url, char *hostname, char* filepath, char *port);
void build_request(char *request,char *filepath,char *hostname,rio_t *rio);
void *thread(void *args);
void clienterror(int fd, char *cause, char *errnum, char *shortmsg, char *longmsg);

sbuf_t sbuf;    /* Shared buffer of connected descriptors */

int main(int argc, char *argv[]){
    int listenfd, connfd;
    char hostname[MAXLINE], port[MAXLINE];
    socklen_t clientlen;
    struct sockaddr_storage clientaddr;
    pthread_t tid;

    if(argc != 2){
        fprintf(stderr,"usage:%s <port> \n",argv[0]);
        exit(0);
    }

    listenfd = open_listenfd(argv[1]);

    sbuf_init(&sbuf, SBUFSIZE);
    
    /* Create worker threads */
    for (int i = 0; i < NTHREADS; i++) {    
        Pthread_create(&tid, NULL, thread, NULL);
    }

    while(1){
        clientlen = sizeof(struct sockaddr_storage);
        connfd = Accept(listenfd, (SA *)&clientaddr, &clientlen);
        sbuf_insert(&sbuf, connfd);
        Getnameinfo((SA *)&clientaddr, clientlen, hostname, MAXLINE, port, MAXLINE, 0);
    }
}

/*
 * doit - forward request from client to server
 */
void doit(int connfd){
    int serverfd;
    char buf[MAXLINE],method[MAXLINE],url[MAXLINE],version[MAXLINE],uri[MAXLINE];
    char hostname[MAXLINE],filepath[MAXLINE],port[MAXLINE],request[MAXLINE];
    size_t n;
    rio_t clientrio,serverrio;

    /* Read request line and headers */
    Rio_readinitb(&clientrio,connfd);
    Rio_readlineb(&clientrio,buf,MAXLINE);
    sscanf(buf,"%s %s %s",method,url,version);
    strcpy(uri,url);

    if(strcasecmp(method,"GET") != 0){
        clienterror(connfd, method, "501", "Not implemented", "Proxy does not implement this method");
        return;
    }
    
    parse_uri(uri,hostname,filepath,port);
    build_request(request,filepath,hostname,&clientrio);
    
    serverfd = open_clientfd(hostname,port);
    Rio_readinitb(&serverrio,serverfd);
    Rio_writen(serverfd,request,(size_t)strlen(request));

    while((n = Rio_readlineb(&serverrio,buf,MAXLINE)) > 0 ){
        Rio_writen(connfd,buf,n);
    }

    Close(serverfd);
}

/*
 * parse_uri - parse uri to hostname, filepath & port
 */
void parse_uri(char *uri, char *hostname,char* filepath,char *port){
    /* http://www.cmu.edu:8080/hub/index.html */
    char* ptr = strstr(uri,"http://");
    if(ptr) ptr += 7;
    else ptr = uri;

    char *tmp = strstr(ptr, ":");
    if(tmp){
        *tmp = '\0';
        tmp++;
        sscanf(ptr, "%s", hostname);
        ptr = strstr(tmp, "/");
        *ptr = '\0';
        sscanf(tmp, "%s", port);
        *ptr = '/';
        sscanf(ptr, "%s", filepath);
    }
    else{
        tmp = strstr(ptr,"/");
        strcpy(port,"80");
        if(tmp){
            *tmp = '\0';
            sscanf(ptr, "%s", hostname);
            *tmp = '/';
            sscanf(tmp, "%s", filepath);
        }
        else{
            sscanf(ptr, "%s", hostname);
        }
    }
}

/*
 * build_request - build request from client to server
 */
void build_request(char *request,char *filepath,char *hostname,rio_t *rio){
    
    /* read request */
    char buf[MAXLINE];
    sprintf(request,"GET %s HTTP/1.0\r\n",filepath);
    
    Rio_readlineb(rio,buf,MAXLINE);
    while(strcmp(buf,"\r\n") != 0){
        if(strstr(buf,"Host")){
            sprintf(request,"%sHost: %s\r\n",request,hostname);
        }
        else if(strstr(buf,"User-Agent")){
            sprintf(request,"%s%s",request,user_agent_hdr);
        }
        else if(strstr(buf,"Connection")){
            sprintf(request,"%sConnection: close\r\n",request);
        }
        else if(strstr(buf,"Proxy-Connection")){
            sprintf(request,"%sProxy-Connection: close\r\n",request);
        }
        else{
            sprintf(request,"%s%s",request,buf);
        }
        Rio_readlineb(rio,buf,MAXLINE);
    }
    sprintf(request,"%s%s",request,"\r\n");
}

/*
 * thread - worker thread
 */
void *thread(void *vargp){
    Pthread_detach(pthread_self());
    while (1) {
        int connfd = sbuf_remove(&sbuf);
        doit(connfd);   /* Service client */
        Close(connfd);
    }
}

/* copy from tiny */
void clienterror(int fd, char *cause, char *errnum, char *shortmsg, char *longmsg) {
    char buf[MAXLINE], body[MAXLINE];

    /* Build the HTTP response body */
    sprintf(body, "<html><title>Tiny Error</title>");
    sprintf(body, "%s<body bgcolor=""ffffff"">\r\n", body);
    sprintf(body, "%s%s: %s\r\n", body, errnum, shortmsg);
    sprintf(body, "%s<p>%s: %s\r\n", body, longmsg, cause);
    sprintf(body, "<hr><em>The Tiny Web Server</em>\r\n");

    /* Print the HTTP response */
    sprintf(buf, "HTTP/1.0 %s %s\r\n", errnum, shortmsg);
    Rio_writen(fd, buf, strlen(buf));
    sprintf(buf, "Content-type: text/html\r\n");
    Rio_writen(fd, buf, strlen(buf));
    sprintf(buf, "Content-length: %d\r\n\r\n", (int)strlen(body));
    Rio_writen(fd, buf, strlen(buf));
    Rio_writen(fd, body, strlen(body));
}

       
